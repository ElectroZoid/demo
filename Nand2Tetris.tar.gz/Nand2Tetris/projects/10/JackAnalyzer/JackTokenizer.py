import os

class JackTokenizer():

    def __init__(self,file):
        self.fp=open(file,'r')
        self.file_size=os.path.getsize(file)
        self.current_token=None
        self.location=self.fp.tell()

        self.keyword=["class","constructor","function","method","field","static","var",
        "int","char","boolean","void","true","false","null","this","let","do","if","else",
        "while","return"]
        self.symbol=["{","}","(",")","[","]",".",",",";","+","-","*","/","&","|","<",">","=","~"]
    
    def hasMoreTokens(self):
        if self.fp.tell()==self.file_size:
            return False
        else:
            return True

    def advance(self):
        s=""
        while True:
            x=self.fp.read(1)

            if x=="/":                                    #comments
                x=self.fp.read(1)
                if x=="/":
                    self.fp.readline()
                    continue
                elif x=="*":
                    while True:
                        x=self.fp.read(1)
                        if x=="*":
                            x=self.fp.read(1)
                            if x=="/":
                                break
                    continue
                else:
                    y=self.fp.tell()
                    self.fp.seek(y-1,0)
                    s="/"
                    break


            if x=="\n":
                if s=="":
                    continue
                else:
                    break

            if s=="" and (x==" " or x=="\t") :                       #leading whitespace
                continue

            if x=="\"":
                s+=x
                while True:
                    x=self.fp.read(1)
                    s+=x
                    if x=="\"":
                        break
                break

            
            if (x in self.symbol) and (s==""):
                s=x
                break
            elif ((x==" ") or (x in self.symbol)) and (s!="") :
                self.fp.seek(int(self.fp.tell()-1),0)
                break
            else:
                s+=x
                
        self.current_token=s


    def tokenType(self):
        if self.current_token in self.keyword:
            return "KEYWORD"
        elif self.current_token in self.symbol:
            return "SYMBOL"
        elif self.current_token[0]=="\"" and self.current_token[-1]=="\"":
            return "STRING_CONST"
        else:
            try:
                int(self.current_token)
                return "INT_CONST"
            except:
                return "IDENTIFIER"

    def keyWord(self):
        return self.current_token.upper()

    def symbol(self):
        return self.current_token

    def identifier(self):
        return self.current_token

    def intVal(self):
        return self.current_token
    
    def stringVal(self):
        return self.current_token[1:-1]

    def close(self):
        self.fp.close()

        
