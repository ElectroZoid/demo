x="ss"
print("\t"*2+x)