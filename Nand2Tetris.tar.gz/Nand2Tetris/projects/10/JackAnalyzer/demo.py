import sys
import JackTokenizer

file=sys.argv[1]

f=JackTokenizer.JackTokenizer(file)
w=open("1.xml","w")

w.write("<tokens>\n")

while f.hasMoreTokens():

    f.advance()
    tt=f.tokenType()

    if tt=="KEYWORD":
        keyword=f.keyWord()
        w.write("<keyword>")
        w.write("{}".format(keyword.lower()))
        w.write("</keyword>\n")

    elif tt=="SYMBOL":

        w.write("<symbol>")
        if f.current_token==">":
            w.write("&gt;")
        elif f.current_token=="<":
            w.write("&lt;")
        elif f.current_token=="&":
            w.write("&amp;")
        else:
            w.write("{}".format(f.current_token))
        w.write("</symbol>\n")
    
    elif tt=="STRING_CONST":
        string=f.stringVal()
        w.write("<stringConstant>")
        w.write("{}".format(string))
        w.write("</stringConstant>\n")


    elif tt=="INT_CONST":
        w.write("<integerConstant>")
        w.write("{}".format(f.intVal()))
        w.write("</integerConstant>\n")

    elif tt=="IDENTIFIER":
        w.write("<identifier>")
        w.write("{}".format(f.identifier()))
        w.write("</identifier>\n")

w.write("</tokens>")

w.close()
f.close()