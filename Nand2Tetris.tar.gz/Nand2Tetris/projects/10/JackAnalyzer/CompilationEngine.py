class CompilationEngine():

    def __init__(self,rfile,wfile):
        self.fp=open(rfile,"r")
        self.wp=open(wfile,"w")
        self.cl=None
        self.indentation=0
    
    def advance(self):
        self.cl=self.fp.readline()

    def getKeyword(self):
        s=self.cl
        s=s[1:]
        i=s.index(">")
        j=s.index("<")
        s=s[i+1,j]
        return s

    def compileClass(self):

        self.wp.write("<class>\n")
        self.indentation+=1

        self.advance()
        self.writeKeyword()

        self.advance()
        self.writeIdentifier()
        
        self.advance()
        self.writeSymbol()

        self.advance()
        while self.getKeyword()=="static" or self.getKeyword()=="field":
            self.compileClassVarDec()
        
        while self.getKeyword=="constructor" or self.getKeyword()=="method" or self.getKeyword()=="function":
            self.compileSubroutine()

        self.writeSymbol()

        self.indentation-=1
        self.wp.write("</class>\n")

    def compileClassVarDec(self):
        
        self.wp.write("\t"*self.indentation+"<classVarDec>\n")
        self.indentation+=1

        self.writeKeyword()

        self.advance()
        self.dataType_varName()

        self.indentation-=1
        self.wp.write("\t"*self.indentation+"</classVarDec>\n")


    def compileSubroutine(self):
        self.wp.write("\t"*self.indentation+"<subroutineDec>\n")
        self.indentation+=1
        
        self.writeKeyword()

        self.advance()
        if self.getKeyword()==

        
