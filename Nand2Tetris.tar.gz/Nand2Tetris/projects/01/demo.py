for i in range(1,49,6):
    print('print("Nand(a=a[\],b=notsel0,out=i\_{});".format(i,i))'.format(i))
    print('print("Nand(a=i\_{},b=i\_{},out=i\_{});".format(i,i,i))'.format(i,i,i+1))

    print('print("Nand(a=i\_{},b=notsel1,out=i\_{});".format(i,i))'.format(i+1,i+2))
    print('print("Nand(a=i\_{},b=i\_{},out=i\_{});".format(i,i,i))'.format(i+2,i+2,i+3))

    print('print("Nand(a=i\_{},b=notsel2,out=i\_{});".format(i,i))'.format(i+3,i+4))
    print('print("Nand(a=i\_{},b=i\_{},out=i\_{});".format(i,i,i))\n'.format(i+4,i+4,i+5))