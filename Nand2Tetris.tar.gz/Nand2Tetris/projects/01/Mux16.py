for i in range(16):
    print("Nand(a=a[{}],b=notsel,out=c{});".format(i,i))
    print("Nand(a=c{},b=c{},out=d{});".format(i,i,i))
    print("Nand(a=b[{}],b=sel,out=e{});".format(i,i))
    print("Nand(a=e{},b=e{},out=f{});".format(i,i,i))
    print("Nand(a=d{},b=d{},out=notd{});".format(i,i,i))
    print("Nand(a=f{}],b=f{},out=notf{});".format(i,i,i))
    print("Nand(a=notd{},b=notf{},out=out[{}]);".format(i,i,i))