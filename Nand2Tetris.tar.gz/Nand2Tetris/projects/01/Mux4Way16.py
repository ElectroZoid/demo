for i in range(16):
    print("And(a=a[{}],b=notsel0,out=e{});".format(i,i))
    print("And(a=e{},b=notsel1,out=f{});".format(i,i))

    print("And(a=b[{}],b=sel[0],out=g{});".format(i,i))
    print("And(a=g{},b=notsel1,out=h{});".format(i,i))

    print("And(a=c[{}],b=notsel0,out=i{});".format(i,i))
    print("And(a=i{},b=sel[1],out=j{});".format(i,i))

    print("And(a=d[{}],b=sel[0],out=k{});".format(i,i))
    print("And(a=k{},b=sel[1],out=l{});".format(i,i))

    print("Or(a=f{},b=h{},out=m{});".format(i,i,i))
    print("Or(a=j{},b=l{},out=n{});".format(i,i,i))
    print("Or(a=m{},b=n{},out=out[{}]);".format(i,i,i))