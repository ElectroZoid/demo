for i in range(16):

    print("Nand(a=a[{}],b=notsel0,out=i{}_1);".format(i,i))
    print("Nand(a=i{}_1,b=i{}_1,out=i{}_2);".format(i,i,i))
    print("Nand(a=i{}_2,b=notsel1,out=i{}_3);".format(i,i))
    print("Nand(a=i{}_3,b=i{}_3,out=i{}_4);".format(i,i,i))
    print("Nand(a=i{}_4,b=notsel2,out=i{}_5);".format(i,i))
    print("Nand(a=i{}_5,b=i{}_5,out=i{}_6);".format(i,i,i))

    print("Nand(a=b[{}],b=sel[0],out=i{}_7);".format(i,i))
    print("Nand(a=i{}_7,b=i{}_7,out=i{}_8);".format(i,i,i))
    print("Nand(a=i{}_8,b=notsel1,out=i{}_9);".format(i,i))
    print("Nand(a=i{}_9,b=i{}_9,out=i{}_10);".format(i,i,i))
    print("Nand(a=i{}_10,b=notsel2,out=i{}_11);".format(i,i))
    print("Nand(a=i{}_11,b=i{}_11,out=i{}_12);".format(i,i,i))

    print("Nand(a=c[{}],b=notsel0,out=i{}_13);".format(i,i))
    print("Nand(a=i{}_13,b=i{}_13,out=i{}_14);".format(i,i,i))
    print("Nand(a=i{}_14,b=sel[1],out=i{}_15);".format(i,i))
    print("Nand(a=i{}_15,b=i{}_15,out=i{}_16);".format(i,i,i))
    print("Nand(a=i{}_16,b=notsel2,out=i{}_17);".format(i,i))
    print("Nand(a=i{}_17,b=i{}_17,out=i{}_18);".format(i,i,i))

    print("Nand(a=d[{}],b=sel[1],out=i{}_19);".format(i,i))
    print("Nand(a=i{}_19,b=i{}_19,out=i{}_20);".format(i,i,i))
    print("Nand(a=i{}_20,b=sel[1],out=i{}_21);".format(i,i))
    print("Nand(a=i{}_21,b=i{}_21,out=i{}_22);".format(i,i,i))
    print("Nand(a=i{}_22,b=notsel2,out=i{}_23);".format(i,i))
    print("Nand(a=i{}_23,b=i{}_23,out=i{}_24);".format(i,i,i))

    print("Nand(a=e[{}],b=notsel0,out=i{}_25);".format(i,i))
    print("Nand(a=i{}_25,b=i{}_25,out=i{}_26);".format(i,i,i))
    print("Nand(a=i{}_26,b=notsel1,out=i{}_27);".format(i,i))
    print("Nand(a=i{}_27,b=i{}_27,out=i{}_28);".format(i,i,i))
    print("Nand(a=i{}_28,b=sel[2],out=i{}_29);".format(i,i))
    print("Nand(a=i{}_29,b=i{}_29,out=i{}_30);".format(i,i,i))

    print("Nand(a=f[{}],b=sel[0],out=i{}_31);".format(i,i))
    print("Nand(a=i{}_31,b=i{}_31,out=i{}_32);".format(i,i,i))
    print("Nand(a=i{}_32,b=notsel1,out=i{}_33);".format(i,i))
    print("Nand(a=i{}_33,b=i{}_33,out=i{}_34);".format(i,i,i))
    print("Nand(a=i{}_34,b=sel[2],out=i{}_35);".format(i,i))
    print("Nand(a=i{}_35,b=i{}_35,out=i{}_36);".format(i,i,i))

    print("Nand(a=g[{}],b=notsel0,out=i{}_37);".format(i,i))
    print("Nand(a=i{}_37,b=i{}_37,out=i{}_38);".format(i,i,i))
    print("Nand(a=i{}_38,b=sel[1],out=i{}_39);".format(i,i))
    print("Nand(a=i{}_39,b=i{}_39,out=i{}_40);".format(i,i,i))
    print("Nand(a=i{}_40,b=sel[2],out=i{}_41);".format(i,i))
    print("Nand(a=i{}_41,b=i{}_41,out=i{}_42);".format(i,i,i))

    print("Nand(a=h[{}],b=sel[0],out=i{}_43);".format(i,i))
    print("Nand(a=i{}_43,b=i{}_43,out=i{}_44);".format(i,i,i))
    print("Nand(a=i{}_44,b=sel[1],out=i{}_45);".format(i,i))
    print("Nand(a=i{}_45,b=i{}_45,out=i{}_46);".format(i,i,i))
    print("Nand(a=i{}_46,b=sel[2],out=i{}_47);".format(i,i))
    print("Nand(a=i{}_47,b=i{}_47,out=i{}_48);".format(i,i,i))

    print("Or(a=i{}_6,b=i{}_12,out=i{}_49);".format(i,i,i))
    print("Or(a=i{}_18,b=i{}_24,out=i{}_50);".format(i,i,i))
    print("Or(a=i{}_30,b=i{}_36,out=i{}_51);".format(i,i,i))
    print("Or(a=i{}_42,b=i{}_48,out=i{}_52);".format(i,i,i))
    print("Or(a=i{}_49,b=i{}_50,out=i{}_53);".format(i,i,i))
    print("Or(a=i{}_51,b=i{}_52,out=i{}_54);".format(i,i,i))
    print("Or(a=i{}_53,b=i{}_54,out=out[{}]);".format(i,i,i))





