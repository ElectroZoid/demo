for i in range(16):
    print("Nand(a=a[{}],b=b[{}],out=out{});".format(i,i,str(i)))
    print("Nand(a=out{},b=out{},out=out[{}]);".format(str(i),str(i),i))