import Parser
import Code

st={'R0':0,'R1':1,'R2':2,'R3':3,'R4':4,'R5':5,'R6':6,'R7':7,'R8':8,'R9':9,'R10':10,'R11':11,'R12':12,'R13':13,'R14':14,'R15':15,
'SP':0,'LCL':1,'ARG':2,'THIS':3,'THAT':4,'SCREEN':16384,'KBD':24576}

file_name=input()
f=Parser.Parser(file_name)

wfile=file_name[:-4]+".hack"
w=open(wfile,"w")

i=0
addr1=16
addr2=16


while f.hasMoreLines():

    f.advance()
    inst_type=f.instructionType()

    if inst_type=="A_INSTRUCTION":
        symbl=f.symbol()
        if symbl not in st:
            try:
                symbl=int(symbl)
            except:
                if symbl.islower():
                    if ('.0' in symbl) or ('.1' in symbl) or ('.2' in symbl) or ('.3' in symbl) or ('.4' in symbl) or ('.5' in symbl) or ('.6' in symbl):
                        st[symbl]=addr2
                        addr2=addr2 + 1
                    else:
                        st[symbl]=addr1
                        addr1=addr1 + 1

        i+=1

    elif inst_type=="L_INSTRUCTION":
        symbl=f.symbol()
        st[symbl]=i

    elif inst_type=="C_INSTRUCTION":
        i+=1


f.fp.seek(0,0)


while f.hasMoreLines():

    inst=''

    f.advance()
    inst_type=f.instructionType()

    if inst_type=="A_INSTRUCTION":
        inst='0'
        symbl=f.symbol()
        if symbl in st:
            back=bin(st[symbl])[2:]
            inst=inst+((15-len(back))*'0')+back
        else:
            back=bin(int(symbl))[2:]
            inst=inst+((15-len(back))*'0')+back

    elif inst_type=="C_INSTRUCTION":
        inst='111'
        inst=inst+Code.comp(f.comp())+Code.dest(f.dest())+Code.jump(f.jump())

    if inst=='':
        pass
    else:
        w.write(inst)
        w.write("\n")
f.fp.close()
w.close()    