import os

class Parser():

    def __init__(self,file):
        self.fp=open(file,"r")
        self.file_size=os.path.getsize(file)
        self.ci=None

    def hasMoreLines(self):
        if self.fp.tell()==self.file_size:
            return False
        else:
            return True
        
    def advance(self):
        while True:
            ci=self.fp.readline()
            ci=ci.strip()
            if ci=="" or ci[0:2]=="//":
                continue
            else:
                if "//" in ci:
                    i=ci.index("//")
                    self.ci=ci[:i].strip()
                    break
                else:
                    self.ci=ci
                    break
    
    def instructionType(self):
        if self.ci[0]=="@":
            return "A_INSTRUCTION"
        elif self.ci[0]=="(":
            return "L_INSTRUCTION"
        else:
            return "C_INSTRUCTION"
    
    def symbol(self):
        if self.ci[0]=="@":
            return self.ci[1:]
        else:
            return self.ci[1:-1]

    def dest(self):
        if "=" in self.ci:
            i=self.ci.index("=")
            return self.ci[:i]
        else:
            return "null"

    def comp(self):
        if "=" in self.ci:
            i=self.ci.index('=')
            if ";" in self.ci:
                j=self.ci.index(";")
                return self.ci[i+1:j]
            else:
                return self.ci[i+1:]
        else:
            if ";" in self.ci:
                i=self.ci.index(";")
                return self.ci[:i]
            else:
                return self.ci

    def jump(self):
        if ";" in self.ci:
            i=self.ci.index(";")
            return self.ci[i+1:]
        else:
            return "null"





