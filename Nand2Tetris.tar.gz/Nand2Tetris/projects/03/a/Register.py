for i in range(16):
    print("Bit(in=in[{}],load=load,out=out[{}]);".format(i,i))