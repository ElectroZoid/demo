for i in range(1,16):
    print("FullAdder(a=a[{}],b=b[{}],c=c{},sum=out[{}],carry=c{});".format(i,i,i,i,i+1))