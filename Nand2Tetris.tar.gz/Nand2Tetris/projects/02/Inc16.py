for i in range(16):
    print("out[{}]=out[{}],".format(i,i),end='')