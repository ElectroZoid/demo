for i in range(8):
    print("in[{}]=fout{},".format(i,i+8),end="")