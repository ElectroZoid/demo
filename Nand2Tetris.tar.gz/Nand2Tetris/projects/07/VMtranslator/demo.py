import sys
import os

rfolder=sys.argv[1]
for i in os.scandir(rfolder):
    if i.is_file() and ".vm" in str(i):
        print(i.path)
262,3