import Parser
import CodeWriter
import sys
import os

rfolder=sys.argv[1]
w=CodeWriter.CodeWriter(rfolder)

for i in os.scandir(rfolder):
    if i.is_file() and ".vm" in str(i):
        rfile=i.path
        file_name=str(i)[11:-2]

        f=Parser.Parser(rfile)
        w.setfilename(file_name)

        while f.hasMoreLines():

            f.advance()
            inst=f.commandType()


            if inst=="C_PUSH" or inst=="C_POP":
                w.writePushPop(inst,f.arg1(),f.arg2())

            elif inst=="C_ARITHMETIC":
                w.writeArithmetic(f.arg1())

            elif inst=="C_IF":
                w.writeIf(f.arg1())

            elif inst=="C_LABEL":
                w.writeLabel(f.arg1())

            elif inst=="C_GOTO":
                w.writeGoto(f.arg1())

            elif inst=="C_CALL":
                w.writeCall(f.arg1(),f.arg2())

            elif inst=="C_FUNCTION":
                w.writeFunction(f.arg1(),f.arg2())

            elif inst=="C_RETURN":
                w.writeReturn()

        f.close()
        
w.close()


