import os

class Parser():

    def __init__(self,file):
        self.fp=open(file,'r')
        self.file_size=os.path.getsize(file)
        self.ci=None
        self.l=None

    def hasMoreLines(self):
        if self.fp.tell()==self.file_size:
            return False
        else:
            return True

    def advance(self):
        while True:
            ci=self.fp.readline()
            ci=ci.strip()
            if ci=="" or ci[0:2]=="//":
                continue
            else:
                if "//" in ci:
                    i=ci.index("//")
                    self.ci=ci[:i].strip()
                    break
                else:
                    self.ci=ci
                    break
        self.l=self.ci.split(" ")

    def commandType(self):
        if self.l[0]=="push":
            return "C_PUSH"
        elif self.l[0]=="pop":
            return "C_POP"
        elif self.l[0]=="label":
            return "C_LABEL"
        elif self.l[0]=="goto":
            return "C_GOTO"
        elif self.l[0]=="if-goto":
            return "C_IF"
        elif self.l[0]=="function":
            return "C_FUNCTION"
        elif self.l[0]=="call":
            return "C_CALL"
        elif self.l[0]=="return":
            return "C_RETURN"
        else:
            return "C_ARITHMETIC"

    def arg1(self):
        if len(self.l)==1:
            return self.l[0]
        else:
            return self.l[1]

    def arg2(self):
        return int(self.l[2])

    def close(self):
        self.fp.close()

        

