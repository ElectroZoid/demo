
class CodeWriter():

    def __init__(self,path):
        filepath=path+"/single.asm"
        self.fp=open(filepath,'w')
        self.file_name=None
        self.function_name=None
        self.i=1
        self.j=1
        self.st={"argument":"ARG","local":"LCL","this":"THIS","that":"THAT"}

        #bootstrap code
        self.fp.write("@256\n")
        self.fp.write("D=A\n")
        self.fp.write("@SP\n")
        self.fp.write("M=D\n")
        self.writeCall("Sys.init",0)


    def setfilename(self,fileName):
        self.file_name=fileName

    def writePushPop(self,command,segment,index):
        if command=="C_PUSH":

            if segment=="constant":
                self.fp.write("@{}\n".format(index))
                self.fp.write("D=A\n")
            elif segment=="argument" or segment=="local" or segment=="this" or segment=="that":

                self.fp.write("@{}\n".format(index))
                self.fp.write("D=A\n")
                self.fp.write("@{}\n".format(self.st[segment]))
                self.fp.write("A=M\n")
                self.fp.write("A=D+A\n")
                self.fp.write("D=M\n")
            elif segment=="temp":
                self.fp.write("@{}\n".format(5+index))
                self.fp.write("D=M\n")
            elif segment=="pointer":
                self.fp.write("@{}\n".format(3+index))
                self.fp.write("D=M\n")
            elif segment=="static":
                self.fp.write("@{}\n".format(self.file_name+str(index)))
                self.fp.write("D=M\n")

            self.fp.write("@SP\n")
            self.fp.write("A=M\n")
            self.fp.write("M=D\n")
            self.fp.write("@SP\n")
            self.fp.write("M=M+1\n")


        else:

            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")


            if segment=="argument" or segment=="local" or segment=="this" or segment=="that":

                self.fp.write("@R13\n")
                self.fp.write("M=D\n")
                self.fp.write("@{}\n".format(index))
                self.fp.write("D=A\n")
                self.fp.write("@{}\n".format(self.st[segment]))
                self.fp.write("D=M+D\n")
                self.fp.write("@R14\n")
                self.fp.write("M=D\n")
                self.fp.write("@R13\n")
                self.fp.write("D=M\n")
                self.fp.write("@R14\n")
                self.fp.write("A=M\n")
                self.fp.write("M=D\n")
            elif segment=="temp":
                self.fp.write("@{}\n".format(5+index))
                self.fp.write("M=D\n")
            elif segment=="pointer":
                self.fp.write("@{}\n".format(3+index))
                self.fp.write("M=D\n")
            elif segment=="static":
                self.fp.write("@{}\n".format(self.file_name+str(index)))
                self.fp.write("M=D\n")


    def writeArithmetic(self,command):
        if command=="add":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=M+D\n")
        elif command=="sub":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=M-D\n")
        elif command=="and":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=D&M\n")
        elif command=="or":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=D|M\n")
        elif command=="neg":
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=-M\n")
        elif command=="not":
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=!M\n")
        elif command=="eq":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("A=A-1\n")
            self.fp.write("D=M-D\n")
            self.fp.write("M=-1\n")
            self.fp.write("@{}\n".format("NEXT"+str(self.i)))
            self.fp.write("D;JEQ\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=0\n")
            self.fp.write("({})\n".format("NEXT"+str(self.i)))
            self.i+=1
        elif command=="gt":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("A=A-1\n")
            self.fp.write("D=M-D\n")
            self.fp.write("M=-1\n")
            self.fp.write("@{}\n".format("NEXT"+str(self.i)))
            self.fp.write("D;JGT\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=0\n")
            self.fp.write("({})\n".format("NEXT"+str(self.i)))
            self.i+=1
        elif command=="lt":
            self.fp.write("@SP\n")
            self.fp.write("M=M-1\n")
            self.fp.write("A=M\n")
            self.fp.write("D=M\n")
            self.fp.write("A=A-1\n")
            self.fp.write("D=M-D\n")
            self.fp.write("M=-1\n")
            self.fp.write("@{}\n".format("NEXT"+str(self.i)))
            self.fp.write("D;JLT\n")
            self.fp.write("@SP\n")
            self.fp.write("A=M-1\n")
            self.fp.write("M=0\n")
            self.fp.write("({})\n".format("NEXT"+str(self.i)))
            self.i+=1

    def writeLabel(self,label):
        self.fp.write("({})\n".format(self.function_name+"$"+label))

    def writeGoto(self,label):
        self.fp.write("@{}\n".format(self.function_name+"$"+label))
        self.fp.write("0;JMP\n")
    
    def writeIf(self,label):
        self.fp.write("@SP\n")
        self.fp.write("M=M-1\n")
        self.fp.write("A=M\n")
        self.fp.write("D=M\n")
        self.fp.write("@{}\n".format(self.function_name+"$"+label))
        self.fp.write("D;JNE\n")

    def writeFunction(self,functionName,nVars):
        self.function_name=functionName

        self.fp.write("({})\n".format(self.function_name))
        for i in range(nVars):
            self.writePushPop("C_PUSH","constant",0)

    def writeCall(self,functionName,nArgs):
        self.fp.write("@{}\n".format(functionName+"$ret."+str(self.j)))
        self.fp.write("D=A\n")
        self.fp.write("@SP\n")
        self.fp.write("A=M\n")
        self.fp.write("M=D\n")
        self.fp.write("@SP\n")
        self.fp.write("M=M+1\n")

        self.fp.write("@1\n")
        self.fp.write("D=M\n")
        self.fp.write("@SP\n")
        self.fp.write("A=M\n")
        self.fp.write("M=D\n")
        self.fp.write("@SP\n")
        self.fp.write("M=M+1\n")
        self.fp.write("@2\n")
        self.fp.write("D=M\n")
        self.fp.write("@SP\n")
        self.fp.write("A=M\n")
        self.fp.write("M=D\n")
        self.fp.write("@SP\n")
        self.fp.write("M=M+1\n")
        self.writePushPop("C_PUSH","pointer",0)
        self.writePushPop("C_PUSH","pointer",1)

        self.fp.write("@5\n")
        self.fp.write("D=A\n")
        self.fp.write("@{}\n".format(nArgs))
        self.fp.write("D=D+A\n")
        self.fp.write("@SP\n")
        self.fp.write("D=M-D\n")
        self.fp.write("@ARG\n")
        self.fp.write("M=D\n")

        self.fp.write("@SP\n")
        self.fp.write("D=M\n")
        self.fp.write("@LCL\n")
        self.fp.write("M=D\n")

        self.fp.write("@{}\n".format(functionName))
        self.fp.write("0;JMP\n")

        self.fp.write("({})\n".format(functionName+"$ret."+str(self.j)))

        self.j+=1

    
    def writeReturn(self):
        
        self.fp.write("@5\n")
        self.fp.write("D=A\n")
        self.fp.write("@LCL\n")
        self.fp.write("D=M-D\n")
        self.fp.write("A=D\n")
        self.fp.write("D=M\n")
        self.fp.write("@R13\n")
        self.fp.write("M=D\n")

        self.fp.write("@LCL\n")
        self.fp.write("D=M\n")
        self.fp.write("@R14\n")
        self.fp.write("M=D\n")

        self.fp.write("@SP\n")
        self.fp.write("M=M-1\n")
        self.fp.write("A=M\n")
        self.fp.write("D=M\n")
        self.fp.write("@ARG\n")
        self.fp.write("A=M\n")
        self.fp.write("M=D\n")

        self.fp.write("@ARG\n")
        self.fp.write("D=M\n")
        self.fp.write("@SP\n")
        self.fp.write("M=D+1\n")

        self.fp.write("@1\n")
        self.fp.write("D=A\n")
        self.fp.write("@R14\n")
        self.fp.write("D=M-D\n")
        self.fp.write("A=D\n")
        self.fp.write("D=M\n")
        self.fp.write("@THAT\n")
        self.fp.write("M=D\n")

        self.fp.write("@2\n")
        self.fp.write("D=A\n")
        self.fp.write("@R14\n")
        self.fp.write("D=M-D\n")
        self.fp.write("A=D\n")
        self.fp.write("D=M\n")
        self.fp.write("@THIS\n")
        self.fp.write("M=D\n")

        self.fp.write("@3\n")
        self.fp.write("D=A\n")
        self.fp.write("@R14\n")
        self.fp.write("D=M-D\n")
        self.fp.write("A=D\n")
        self.fp.write("D=M\n")
        self.fp.write("@ARG\n")
        self.fp.write("M=D\n")

        self.fp.write("@4\n")
        self.fp.write("D=A\n")
        self.fp.write("@R14\n")
        self.fp.write("D=M-D\n")
        self.fp.write("A=D\n")
        self.fp.write("D=M\n")
        self.fp.write("@LCL\n")
        self.fp.write("M=D\n")

        self.fp.write("@R13\n")
        self.fp.write("A=M\n")
        self.fp.write("0;JMP\n")



    def close(self):
        self.fp.close()







                
